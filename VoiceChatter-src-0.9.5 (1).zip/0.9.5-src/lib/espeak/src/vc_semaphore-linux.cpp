#include "vc_semaphore.h"

#include <CoreServices/CoreServices.h>

struct VC_Semaphore
{
   MPSemaphoreID mSemaphore;
};

int VC_Semaphore_Create(void** sem)
{
   VC_Semaphore* semaphore = (VC_Semaphore*)*sem;
   semaphore = (VC_Semaphore*)malloc(sizeof(VC_Semaphore));

   int result = MPCreateSemaphore(0x7FFFFFFF, 0, &semaphore->mSemaphore);
   if (result == kInvalidID)
      return -1;
   return 0;
}

void VC_Semaphore_Destroy(void** sem)
{
   VC_Semaphore* semaphore = (VC_Semaphore*)*sem;
   MPDeleteSemaphore(semaphore->mSemaphore);
   MPYield();
   free(semaphore);
   *sem = NULL;
}

int VC_Semaphore_Inc(void* sem)
{
   VC_Semaphore* semaphore = (VC_Semaphore*)sem;
   OSStatus result = MPSignalSemaphore(semaphore->mSemaphore);
   MPYield();
   if (result != noErr)
      return -1;
   return 0;
}

int VC_Semaphore_Dec(void* sem)
{
   VC_Semaphore* semaphore = (VC_Semaphore*)sem;
   OSStatus result = MPWaitOnSemaphore(semaphore->mSemaphore, kDurationForever);
   if (result != noErr)
      return -1;
   return 0;
}

int VC_Semaphore_TryDec(void* sem)
{
   VC_Semaphore* semaphore = (VC_Semaphore*)sem;
   return VC_Semaphore_TimedDec(semaphore, (unsigned long)kDurationImmediate);
}

int VC_Semaphore_TimedDec(void* sem, unsigned long timeout)
{
   VC_Semaphore* semaphore = (VC_Semaphore*)sem;
   OSStatus result = MPWaitOnSemaphore(semaphore->mSemaphore, (Duration)timeout);
   if (result == kMPTimeoutErr)
      return 1;
   if (result != noErr)
      return -1;

   return 0;
}



