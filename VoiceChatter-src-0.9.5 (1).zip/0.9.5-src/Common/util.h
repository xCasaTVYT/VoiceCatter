#ifndef _UTIL_H_
#define _UTIL_H_

#include "types.h"

namespace Util
{
   U16 GetPktU16(char* pkt);
   U32 GetPktU32(char* pkt);

   void SetPktU16(char* pkt, U16 val);
   void SetPktU32(char* pkt, U32 val);
}


#endif

