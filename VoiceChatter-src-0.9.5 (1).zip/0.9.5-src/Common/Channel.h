#ifndef _CHANNEL_H_
#define _CHANNEL_H_


#include "types.h"
#include <map>
class Client;

#define MAX_CHANNEL_NAME_LENGTH 32

#ifdef WIN32
#pragma warning (disable : 4512)
#endif

class Channel
{
protected:
   Channel(char* name, Channel* parent, U16 id, bool hasPassword);
public:
   virtual ~Channel();

   std::map<U16, Channel*>& GetSubchannels() { return mSubchannels; }
   std::map<U16, Client*>& GetClients() { return mClients; }

   void SetName(char* name);
   char* GetName() { return mName; }
   Channel* GetParent() const { return mParent; }
   U16 GetID() const { return mID; }

   void SetHasPassword(bool hasPassword) { mHasPassword = hasPassword; }
   bool HasPassword() const { return mHasPassword; }

   void AddClient(Client* client);
   void RemoveClient(Client* client);

protected:
   Channel* mParent;
   const U16 mID;
   bool mHasPassword;
   std::map<U16, Channel*> mSubchannels;
   std::map<U16, Client*> mClients;

   char mName[MAX_CHANNEL_NAME_LENGTH+1];

   void AddSubchannel(Channel* subchan);
   void RemoveSubchannel(Channel* subchan);

private:
   bool mDestructing;
};



#endif

