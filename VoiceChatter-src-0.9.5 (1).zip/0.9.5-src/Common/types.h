#ifndef _TYPES_H_
#define _TYPES_H_


typedef signed char        S8;      ///< Compiler independent Signed Char
typedef unsigned char      U8;      ///< Compiler independent Unsigned Char

typedef signed short       S16;     ///< Compiler independent Signed 16-bit short
typedef unsigned short     U16;     ///< Compiler independent Unsigned 16-bit short

typedef signed int         S32;     ///< Compiler independent Signed 32-bit integer
typedef unsigned int       U32;     ///< Compiler independent Unsigned 32-bit integer

typedef float              F32;     ///< Compiler independent 32-bit float
typedef double             F64;     ///< Compiler independent 64-bit float

#ifdef WIN32
typedef signed __int64   S64;
typedef unsigned __int64 U64;
#endif

#ifdef LINUX
typedef signed long long    S64;
typedef unsigned long long  U64;
#endif

#ifdef LINUX
#define _snprintf snprintf
#endif

#endif
