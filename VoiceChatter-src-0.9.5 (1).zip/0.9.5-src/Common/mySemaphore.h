#ifndef _SEMAPHORE_H_
#define _SEMAPHORE_H_


struct Semaphore
{
   virtual void Inc() = 0;
   virtual void Dec() = 0;
   virtual bool TryDec() = 0;
   virtual ~Semaphore() {}

   static Semaphore* Create(int count);
};


#endif

