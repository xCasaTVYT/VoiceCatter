#include "mySemaphore.h"
#include <CoreServices/CoreServices.h>

struct MacSemaphore : public Semaphore
{
   MacSemaphore(int count);
   virtual ~MacSemaphore();
   virtual void Inc();
   virtual void Dec();
   virtual bool TryDec();

   MPSemaphoreID mSemaphore;
};


Semaphore* Semaphore::Create(int count)
{
   return new MacSemaphore(count);
}

MacSemaphore::MacSemaphore(int count)
{
   MPCreateSemaphore(0x7FFFFFFF, count, &mSemaphore);
}

MacSemaphore::~MacSemaphore()
{
   MPDeleteSemaphore(mSemaphore);
   MPYield();
}

void MacSemaphore::Inc()
{
   OSStatus err = MPSignalSemaphore(mSemaphore);
   MPYield();
}

void MacSemaphore::Dec()
{
   OSStatus err = MPWaitOnSemaphore(mSemaphore, kDurationForever);
}

bool MacSemaphore::TryDec()
{
   OSStatus err = MPWaitOnSemaphore(mSemaphore, kDurationImmediate);
   if (err == kMPTimeoutErr)
      return false;
   return true;
}

