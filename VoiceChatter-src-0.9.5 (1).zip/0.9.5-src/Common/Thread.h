#ifndef _THREAD_H_
#define _THREAD_H_

class Thread
{
public:
   virtual ~Thread() {}
   static Thread* Create(void* (*fptr)(void*));

   virtual void Start(void* arg) = 0;
   virtual void Stop() = 0;
   virtual void* Join() = 0;

protected:
   void* (*mFPtr)(void*);
   Thread(void* (*fptr)(void*)) : mFPtr(fptr)
   {}
};




#endif
