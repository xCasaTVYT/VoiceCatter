#include "Client.h"
#include "Channel.h"
#include <assert.h>

Client::Client(char* name, U16 id, Channel* channel)
:  mID(id),
   mChannel(channel)
{
   mComment[0] = '\0';
   mComment[255] = '\0';
   mChannel->AddClient(this);
   strcpy(mName, name);
}

Client::~Client()
{
   assert(mChannel != NULL);
   mChannel->RemoveClient(this);
}

void Client::SetChannel(Channel* channel)
{
   if (mChannel == channel)
      return;

   if (mChannel)
      mChannel->RemoveClient(this);
   mChannel = channel;
   mChannel->AddClient(this);
}

void Client::SetComment(const char* comment)
{
   strncpy(mComment, comment, 255);
}


