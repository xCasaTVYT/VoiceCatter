#ifndef _CLIENT_H_
#define _CLIENT_H_

#include "types.h"



class Channel;

#ifdef WIN32
//this is for the compiler warning "Unable to create copy contructor" because
//of the !const! U16 mID variable.  Well guess what - we don't need a copy
//constructor anyway.  If we're copying these objects, then we have other
//problems to deal with.
#pragma warning (disable : 4512)
#endif

class Client
{
protected:
   Client(char* name, U16 id, Channel* channel);

public:
   virtual ~Client();

   const char* GetName() const { return mName; }
   const char* GetComment() const { return mComment; }
   U16 GetID() const { return mID; }
   Channel* GetChannel() const { return mChannel; }
   void SetChannel(Channel* channel);
   void SetComment(const char* comment);

protected:
   char mName[32];
   char mComment[256];
   const U16 mID;
   Channel* mChannel;
};


#endif

