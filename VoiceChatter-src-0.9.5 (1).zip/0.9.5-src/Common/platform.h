#ifndef _PLATFORM_H_
#define _PLATFORM_H_

#include "types.h"
#include "Thread.h"
#include "mutex.h"
#include "mySemaphore.h"

namespace Platform
{
   void Sleep(U32 ms);
   U64 GetTimeMS();

   int MakeDir(const char* dir);
   void ExpandPath(const char* dir, char* output, int outputSize);
}



#endif

