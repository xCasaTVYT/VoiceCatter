#ifndef _IPADDR_H_
#define _IPADDR_H_

#include "types.h"

class IPAddr
{
   U32 mIP;
   U16 mPort;
};


#endif
