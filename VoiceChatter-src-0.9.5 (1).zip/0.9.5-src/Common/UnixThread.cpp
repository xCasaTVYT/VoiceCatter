#include "Thread.h"
#include <signal.h>
#include <pthread.h>

class UnixThread : public Thread
{
public:
   UnixThread(void* (*fptr)(void*)) : Thread(fptr)
   {
      mRunning = false;
   }
   ~UnixThread()
   {
      Stop();
   }

   void Start(void* arg);
   void Stop();
   void* Join();

private:
   pthread_t mHandle;
   bool mRunning;
};

Thread* Thread::Create(void* (*fptr)(void*))
{
   return new UnixThread(fptr);
}

void UnixThread::Start(void* arg)
{
   pthread_create(&mHandle, NULL, mFPtr, arg);
   mRunning = true;
}

void UnixThread::Stop()
{
//   if (mHandle != INVALID_HANDLE_VALUE)
//      TerminateThread(mHandle, 0);
//   mHandle = INVALID_HANDLE_VALUE;
   if (mRunning)
      pthread_cancel(mHandle);
   mRunning = false;
}

void* UnixThread::Join()
{
   void* retval;
   pthread_join(mHandle, &retval);
   mRunning = false;
   return retval;
}
