#ifndef _LOG_H_
#define _LOG_H_

#include <time.h>
#include <stdio.h>
#include "types.h"
#include "mutex.h"

//relatively simply log-to-file class (with log rotation?)
class Log
{
public:
   enum RotationPeriod
   {
      Rot_Never = 0,
      Rot_Hour,
      Rot_Day,
      Rot_Week,
      Rot_Minute, //just for debugging!
   };

   //if flushAlways is set, then the log will flush to disk after every write
   Log(const char* name, RotationPeriod rotationPeriod, bool flushAlways = false);
   ~Log();
   void Write(const char* fmt, ...);

protected:
   bool mFlushAlways;
   RotationPeriod mRotationPeriod;

   FILE* mFile;
   time_t mNextRotationTime;
   time_t mLastRotationTime;
   Mutex* mMutex;
   char mFileName[1024];

   static bool smInitialized;
   static time_t smStartTime;
   static U64 smStartMS;
   static void Init();
   static void WhatTimeIsIt(time_t* secs, U16* ms);

   void SetupRotation(time_t when);
   void Rotate();
};

#endif

