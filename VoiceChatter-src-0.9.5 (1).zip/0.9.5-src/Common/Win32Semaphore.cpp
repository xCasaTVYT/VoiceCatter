#include "mySemaphore.h"
#include <windows.h>


struct Win32Semaphore : public Semaphore
{
   Win32Semaphore(int count);
   virtual ~Win32Semaphore();
   virtual void Inc();
   virtual void Dec();
   virtual bool TryDec();

   HANDLE mSemaphore;
};

Semaphore* Semaphore::Create(int count)
{
   return new Win32Semaphore(count);
}

Win32Semaphore::Win32Semaphore(int count)
{
   mSemaphore = CreateSemaphore(NULL, count, 100000, NULL);
}

Win32Semaphore::~Win32Semaphore()
{
   CloseHandle(mSemaphore);
}

void Win32Semaphore::Inc()
{
   ReleaseSemaphore(mSemaphore, 1, NULL);
}

void Win32Semaphore::Dec()
{
   WaitForSingleObject(mSemaphore, INFINITE);
}

bool Win32Semaphore::TryDec()
{
   return WaitForSingleObject(mSemaphore, 0) == WAIT_OBJECT_0;
}
