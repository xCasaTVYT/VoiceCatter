#include "mySemaphore.h"
#include <semaphore.h>

struct UnixSemaphore : public Semaphore
{
   UnixSemaphore(int count);
   virtual ~UnixSemaphore();
   virtual void Inc();
   virtual void Dec();
   virtual bool TryDec();

   sem_t mSemaphore;
};

Semaphore* Semaphore::Create(int count)
{
   return new UnixSemaphore(count);
}

UnixSemaphore::UnixSemaphore(int count)
{
   sem_init(&mSemaphore, 0, count);
}

UnixSemaphore::~UnixSemaphore()
{
   sem_destroy(&mSemaphore);
}

void UnixSemaphore::Inc()
{
   sem_post(&mSemaphore);
}

void UnixSemaphore::Dec()
{
   //apparently, this can get "interrupted by a signal", which happens when running through GDB
   while (sem_wait(&mSemaphore) != 0) {}
}

bool UnixSemaphore::TryDec()
{
   return sem_trywait(&mSemaphore) == 0;
}
