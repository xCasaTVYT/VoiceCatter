#include "mutex.h"
#include <pthread.h>

struct UnixMutex : public Mutex
{
   pthread_mutex_t mutex;

   UnixMutex()
   {
      pthread_mutexattr_t attr;
      pthread_mutexattr_init(&attr);
      pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
      pthread_mutex_init(&mutex, &attr);
   }

   virtual ~UnixMutex()
   {
      pthread_mutex_destroy(&mutex);
   }

   virtual void Lock()
   {
      pthread_mutex_lock(&mutex);
   }

   virtual bool TryLock()
   {
      return pthread_mutex_trylock(&mutex) == 0;
   }

   virtual void Unlock()
   {
      pthread_mutex_unlock(&mutex);
   }
};

Mutex* Mutex::Create()
{
   return new UnixMutex();
}


