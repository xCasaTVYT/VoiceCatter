#include "Thread.h"
#include <windows.h>

class Win32Thread : public Thread
{
public:
   Win32Thread(void* (*fptr)(void*)) : Thread(fptr)
   {}
   ~Win32Thread()
   {
      Stop();
   }

   void Start(void* arg);
   void Stop();
   void* Join();

private:
   HANDLE mHandle;
};

Thread* Thread::Create(void* (*fptr)(void*))
{
   return new Win32Thread(fptr);
}

void Win32Thread::Start(void* arg)
{
   mHandle = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)mFPtr, arg, 0, NULL);
}

void Win32Thread::Stop()
{
   if (mHandle != INVALID_HANDLE_VALUE)
      TerminateThread(mHandle, 0);
   mHandle = INVALID_HANDLE_VALUE;
}

void* Win32Thread::Join()
{
   WaitForSingleObject(mHandle, INFINITE);
   mHandle = INVALID_HANDLE_VALUE;
   return NULL;
}
