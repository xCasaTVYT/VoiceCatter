#ifndef _MUTEX_H_
#define _MUTEX_H_


struct Mutex
{
   virtual void Lock() = 0;
   virtual bool TryLock() = 0;
   virtual void Unlock() = 0;
   virtual ~Mutex() {}

   static Mutex* Create();
};


#endif
