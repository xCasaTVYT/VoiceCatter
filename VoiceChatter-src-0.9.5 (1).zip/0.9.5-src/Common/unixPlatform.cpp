#include "platform.h"
#include <unistd.h>
#include <time.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <pwd.h>
#include <string.h>

void Platform::Sleep(U32 ms)
{
   usleep(ms * 1000);
}

U64 Platform::GetTimeMS()
{
   timeval tv;
   gettimeofday(&tv, NULL);

   return (U64)tv.tv_sec * 1000 + (U64)tv.tv_usec / 1000;
}

int Platform::MakeDir(const char* dir)
{
   char fullDir[512];
   ExpandPath(dir, fullDir, 512);

   umask(0);
   int ret = mkdir(fullDir, S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH);
   if (ret == 0)
      return 0;

   return errno;
}

void Platform::ExpandPath(const char* path, char* output, int outputLength)
{
   if (path[0] == '~' && path[1] == '/')
   {
      struct passwd* userInfo = getpwuid(getuid());
      strcpy(output, userInfo->pw_dir);
      if (output[strlen(output)-1] != '/')
         strcat(output, "/");
      strncat(output, path + 2, outputLength - strlen(output));
   }
   else
      strncpy(output, path, outputLength);

   output[outputLength-1] = '\0';
}

