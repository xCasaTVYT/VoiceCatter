#include "GPManager.h"

#include "vprotocol.h"
#include "util.h"
#include <assert.h>

const U32 TIMEOUT_SEND_MS = 400;

//TODO: might need to delay deletion of these things somehow
Mutex* GPManager::smManagerMutex = Mutex::Create();
Thread* GPManager::smTimeoutThread = NULL;
std::list<GPManager*> GPManager::smManagers;

GPManager::GPManager(SOCKET sock, sockaddr_in addr, U16 key, void* tag, void (*recvCallback)(void* tag, char* data, U32 dataLen, sockaddr_in props))
: mSocket(sock), mAddr(addr), mKey(key), mTag(tag), mRecvCallback(recvCallback),
  mSeqNumSend(0), mSeqNumRecv(0), mSentPackets(0)
{
   mSendMutex = Mutex::Create();
   mRecvMutex = Mutex::Create();

   for (int i = 0; i < WINDOW_SIZE; i++)
      mRcvdPkts[i].data = NULL;

   AddManager(this);
}

GPManager::~GPManager()
{
   mSendMutex->Lock();
   mRecvMutex->Lock();
   RemoveManager(this);
   for (GPIter itr = mPacketQueue.begin(); itr != mPacketQueue.end(); itr = mPacketQueue.erase(itr))
      delete (*itr);

   mRecvMutex->Unlock();
   mSendMutex->Unlock();
   delete mSendMutex;
   delete mRecvMutex;
}

void GPManager::Destroy()
{
   if (smTimeoutThread)
   {
      delete smTimeoutThread;
      smTimeoutThread = NULL;
   }

   for (std::list<GPManager*>::iterator itr = smManagers.begin(); itr != smManagers.end(); itr++)
      delete (*itr);
   smManagers.clear();
   delete smManagerMutex;
}

void GPManager::Send(char* data, U32 dataLen)
{
   mSendMutex->Lock();
   GuaranteedPacket* gp = new GuaranteedPacket(mKey, mSeqNumSend++, data, dataLen);

   mPacketQueue.push_back(gp);
   mSendMutex->Unlock();

   FillWindow();
}

void GPManager::Recv(char* data, U32 dataLen, sockaddr_in props)
{
   if (dataLen < 7)
   {
      printf("Bad receive guaranteed length\n");
      return;
   }

   if (props.sin_addr.s_addr != props.sin_addr.s_addr)
   {
      printf("Received from wrong source\n");
      return;
   }

   U32 seq = Util::GetPktU32(data+3);

   mRecvMutex->Lock();

   //ack this packet
   const int ackBuffLen = 7;
   char ackBuff[ackBuffLen];
   ackBuff[0] = GUARANTEED_ACK;
   Util::SetPktU16(ackBuff+1, mKey);
   Util::SetPktU32(ackBuff+3, seq);
   sendto(mSocket, ackBuff, ackBuffLen, 0, (const sockaddr*)&mAddr, sizeof(sockaddr_in));

   //if we got a packet but the ack got lost, then the sender will resend
   //a packet with a seq that is less than mSeqNumRecv, but it will be
   //within WINDOW_SIZE seq's of mSeqNumRecv - this is normal, but throw it out
   if (mSeqNumRecv != seq && mSeqNumRecv - seq <= WINDOW_SIZE)
   {
      printf("Ack lost on: %d, waiting for %d\n", seq, mSeqNumRecv);
      mRecvMutex->Unlock();
      return;
   }

   //if the seq is more than (WINDOW_SIZE-1) ahead of mSeqNumRecv, then either the
   //sender/receiver WINDOW_SIZE is not equal, there is a bug in the sender code,
   //or we are connected to a malicious server - this is NOT normal, so throw it out
   if (seq - mSeqNumRecv > WINDOW_SIZE-1)
   {
     printf("BAD! Seq %d is outside of receive window, expecting %d\n", seq, mSeqNumRecv);
     mRecvMutex->Unlock();
     return;
   }

   //seq is now guaranteed to be mSeqNumRecv <= seq < WINDOW_SIZE-1
   //i.e. it is in the valid range of the receive ringbuffer

   //see if this has already been acked - if so, don't do any more
   if (ReceivedPkt(seq))
   {
      printf("Duplicate packet: %d\n", seq);
      mRecvMutex->Unlock();
      return;
   }

   //printf("Got packet %d\n", seq);
   //track this packet
   TrackPkt(data, dataLen, props);

   //if in order, use callback to pass up the first series of acked packets
   //and slide the receive window by that many
   if (seq == mSeqNumRecv)
   {
      while (ReceivedPkt(mSeqNumRecv))
      {
         //don't go into and infinite loop
         assert(mSeqNumRecv - seq <= WINDOW_SIZE);

         U32 idx = mSeqNumRecv % WINDOW_SIZE;
         RcvdPkt* pkt = &mRcvdPkts[idx];

         //printf("Passing up packet %d\n", mSeqNumRecv);
         (*mRecvCallback)(mTag, pkt->data, pkt->dataLen, pkt->props);

         delete [] pkt->data;
         pkt->data = NULL;
         mSeqNumRecv++;
      }
   }

   mRecvMutex->Unlock();
}

bool GPManager::ReceivedPkt(U32 seq)
{
   //TODO: check to see that seq is in a valid range of mSeqNumRecv
   U32 idx = seq % WINDOW_SIZE;
   return mRcvdPkts[idx].data != NULL;
}

void GPManager::TrackPkt(char* data, U32 dataLen, sockaddr_in props)
{
   U32 seq = Util::GetPktU32(data+3);
   U32 idx = seq % WINDOW_SIZE;

   if (mRcvdPkts[idx].data)
   {
      printf("BAD! data already present\n");
      delete [] mRcvdPkts[idx].data;
   }

   mRcvdPkts[idx].data = new char[dataLen-7];
   memcpy(mRcvdPkts[idx].data, data+7, dataLen-7);
   mRcvdPkts[idx].dataLen = dataLen-7;
   mRcvdPkts[idx].props = props;
}


void GPManager::Ack(char* data, U32 dataLen)
{
   if (dataLen != 7)
   {
      printf("Bad ack length\n");
      return;
   }

   U32 seq = Util::GetPktU32(data+3);
   //find this packet in the window
   mSendMutex->Lock();

   //this is the start of the sending window
   if (mPacketQueue.size() == 0)
   {
      printf("Got ack, but no packets to ack\n");
      mSendMutex->Unlock();
      return;
   }
   U32 firstSeq = mPacketQueue[0]->GetSeq();

   //if seq is < firstSeq, then this ack is for a packet that we
   //already got an ack for - so ignore it
   if (firstSeq != seq && firstSeq - seq < WINDOW_SIZE)
   {
      printf("Already got ack for %d\n", seq);
      mSendMutex->Unlock();
      return;
   }

   //if seq is more than WINDOW_SIZE-1 ahead of firstSeq, then something went wrong
   //we should only be sending packets that are up to and including WINDOW_SIZE-1
   //ahead of firstSeq, so either there is a bug on the receiving side, or we are
   //connected to a malicious client - we should probably disconnect them (TODO)
   //but for now just throw away the ack
   if (seq - firstSeq > WINDOW_SIZE-1)
   {
      //don't process acks that are not in the window
      printf("Bad seq num %d, expecting %d\n", seq, firstSeq);
      mSendMutex->Unlock();
      return;
   }

   //seq is now guaranteed to be within the window of goodness
   
   //printf("Received ack for %d\n", seq);
   //TODO: this isFound stuff is just for debugging
   //TODO: there should be a way to calculate where this sequence number is
   bool found = false;
   GPIter itr = mPacketQueue.begin();
   for (int i = 0; i < WINDOW_SIZE && itr != mPacketQueue.end(); i++, itr++)
   {
      if ((*itr)->GetSeq() == seq)
      {
         //printf("Found packet for ack %d\n", seq);
         (*itr)->SetAcked();
         OnAck();
         found = true;
         break;
      }
   }
   if (!found)
      printf("Could not find sequence number in window\n");
   mSendMutex->Unlock();
}

void GPManager::OnAck()
{
   //printf("Got a valid ack\n");

   //check for in-order ack
   if (mPacketQueue.front()->WasAcked())
   {
      //printf("Ack is in order\n");
      //slide the window until a non-acked packet
      for (U32 i = 0; i < WINDOW_SIZE && mPacketQueue.size() > 0 && mSentPackets > 0; i++)
      {
         if (!mPacketQueue.front()->WasAcked())
            break;

         //printf("Forgetting about packet %d\n", mPacketQueue.front()->GetSeq());
         delete mPacketQueue.front();
         mPacketQueue.pop_front();
         mSentPackets--;
      }
      
      FillWindow();
   }
   else
   {
      //printf("Ack is out of order\n");
      //out of order ack - resend all non-acked packets until the first acked packet in window
      GPIter itr = mPacketQueue.begin();
      for (U32 i = 0; i < mSentPackets; i++, itr++)
      {
         if ((*itr)->WasAcked())
            break;

         printf("Resending packet %d\n", (*itr)->GetSeq());
         sendto(mSocket, (*itr)->GetData(), (*itr)->GetSize(), 0, (const sockaddr*)&mAddr, sizeof(sockaddr_in));
      }
   }
}

void GPManager::FillWindow()
{
   mSendMutex->Lock();
   for (GPIter itr = mPacketQueue.begin() + mSentPackets;
         mSentPackets < WINDOW_SIZE && itr != mPacketQueue.end(); mSentPackets++, itr++)
   {
      //printf("Sending packet %d\n", (*itr)->GetSeq());
      sendto(mSocket, (*itr)->GetData(), (*itr)->GetSize(), 0, (const sockaddr*)&mAddr, sizeof(sockaddr_in));
      (*itr)->mLastTimeSent = Platform::GetTimeMS();
   }
   mSendMutex->Unlock();
}



void GPManager::Tick()
{
   mSendMutex->Lock();

   U64 msNow = Platform::GetTimeMS();

   GPIter itr = mPacketQueue.begin();
   for (U32 i = 0; i < mSentPackets; i++, itr++)
   {
      if (msNow - (*itr)->mLastTimeSent > TIMEOUT_SEND_MS)
      {
         printf("Resending timed out packet %d\n", (*itr)->GetSeq());
         sendto(mSocket, (*itr)->GetData(), (*itr)->GetSize(), 0, (const sockaddr*)&mAddr, sizeof(sockaddr_in));
         (*itr)->mLastTimeSent = Platform::GetTimeMS();
      }
   }

   mSendMutex->Unlock();
}

void* GPManager::TimeoutLoop(void*)
{
   while (true)
   {
      smManagerMutex->Lock();
      for (std::list<GPManager*>::iterator itr = smManagers.begin(); itr != smManagers.end(); itr++)
         (*itr)->Tick();
      smManagerMutex->Unlock();
      Platform::Sleep(50);
   }
   return NULL;
}

void GPManager::AddManager(GPManager* manager)
{
   smManagerMutex->Lock();
   if (!smTimeoutThread)
   {
      smTimeoutThread = Thread::Create(TimeoutLoop);
      smTimeoutThread->Start(NULL);
   }
   smManagers.push_back(manager);
   smManagerMutex->Unlock();
}

void GPManager::RemoveManager(GPManager* manager)
{
   smManagerMutex->Lock();
   for (std::list<GPManager*>::iterator itr = smManagers.begin(); itr != smManagers.end(); itr++)
   {
      if ((*itr) == manager)
      {
         smManagers.erase(itr);
         smManagerMutex->Unlock();
         return;
      }
   }
   if (smManagers.size() == 0)
   {
      delete smTimeoutThread;
      smTimeoutThread = NULL;
   }
   smManagerMutex->Unlock();
}

