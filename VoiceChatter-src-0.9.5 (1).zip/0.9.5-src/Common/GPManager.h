#ifndef _GPMANAGER_H_
#define _GPMANAGER_H_

#include "GuaranteedPacket.h"
#include "net.h"
#include "platform.h"

#include <deque>
#include <list>

//NEXT: might want to transmit the window size
#define WINDOW_SIZE 10

class GPManager
{
public:
   GPManager(SOCKET sock, sockaddr_in addr, U16 key, void* tag, void (*recvCallback)(void* tag, char* data, U32 dataLen, sockaddr_in props));
   ~GPManager();

   void Send(char* data, U32 dataLen);
   void Recv(char* data, U32 dataLen, sockaddr_in props);
   void Ack(char* data, U32 dataLen);

   static void Destroy();

private:
   Mutex* mSendMutex;
   Mutex* mRecvMutex;
   SOCKET mSocket;
   sockaddr_in mAddr;
   U16 mKey;
   U32 mSeqNumSend; //NEXT sequence number to send
   U32 mSeqNumRecv; //NEXT sequence number to expect

   U32 mSentPackets; //number of packets in the window that have been sent

   void* mTag;
   void (*mRecvCallback)(void* tag, char* data, U32 dataLen, sockaddr_in props);

   std::deque<GuaranteedPacket*> mPacketQueue;
   typedef std::deque<GuaranteedPacket*>::iterator GPIter;

   void OnAck();
   void FillWindow();

   //ring buffer to keep track of which packets we've received
   struct RcvdPkt
   {
      char* data;
      U32 dataLen;
      sockaddr_in props;
   };

   RcvdPkt mRcvdPkts[WINDOW_SIZE];
   bool ReceivedPkt(U32 seq);
   void TrackPkt(char* data, U32 dataLen, sockaddr_in props);

   void Tick();

   //static managerial stuff
   static std::list<GPManager*> smManagers;
   static Mutex* smManagerMutex;
   static Thread* smTimeoutThread;
   static void* TimeoutLoop(void*);
   static void AddManager(GPManager* manager);
   static void RemoveManager(GPManager* manager);
};



#endif

