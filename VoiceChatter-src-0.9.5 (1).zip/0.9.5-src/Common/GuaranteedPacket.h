#ifndef _GUARANTEEDPACKET_H_
#define _GUARANTEEDPACKET_H_

#include "types.h"

class GuaranteedPacket
{
public:
   GuaranteedPacket(U16 key, U32 seqnum, char* data, U32 size);
   ~GuaranteedPacket();

   char* GetData() { return mData; }
   U32 GetSize() { return mSize; }
   U32 GetSeq() { return mSeq; }

   void SetAcked() { mAcked = true; }
   bool WasAcked() { return mAcked; }

   U64 mLastTimeSent;

private:
   U32 mSeq;
   char* mData;
   U32 mSize;
   bool mAcked;
};

#endif

