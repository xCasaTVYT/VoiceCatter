#include "mutex.h"
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0600
#endif
#include <windows.h>

struct Win32Mutex : public Mutex
{
   CRITICAL_SECTION mutex;

   Win32Mutex()
   {
      InitializeCriticalSection(&mutex);
   }
   virtual ~Win32Mutex()
   {
      DeleteCriticalSection(&mutex);
   }

   virtual void Lock()
   {
      EnterCriticalSection(&mutex);
   }

   virtual bool TryLock()
   {
      return TryEnterCriticalSection(&mutex) != 0;
   }

   virtual void Unlock()
   {
      LeaveCriticalSection(&mutex);
   }
};

Mutex* Mutex::Create()
{
   return new Win32Mutex();
}