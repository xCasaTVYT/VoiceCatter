#ifndef _CONFIG_H_
#define _CONFIG_H_

#include <stdio.h>
#include <vector>
#include <string>
#include <list>
#include "types.h"
#include "strings.h"

#define MAX_FILENAME_LEN 512

class Config
{
public:
   Config(const char* path, const char* filename);
   ~Config();

   bool ReadValue(char* key, char* name, U32* value, bool create);
   bool ReadValue(char* key, char* name, U16* value, bool create);
   bool ReadValue(char* key, char* name, U8*  value, bool create);
   bool ReadValue(char* key, char* name, S32* value, bool create);
   bool ReadValue(char* key, char* name, S16* value, bool create);
   bool ReadValue(char* key, char* name, char* value, size_t valueLen, bool create);
   bool ReadValue(char* key, char* name, F32* value, bool create);
   bool ReadValue(char* key, char* name, F64* value, bool create);
   bool ReadValue(char* key, char* name, bool* value, bool create);
   
   void WriteValue(char* key, char* name, U32 value);
   void WriteValue(char* key, char* name, U16 value);
   void WriteValue(char* key, char* name, U8  value);
   void WriteValue(char* key, char* name, S32 value);
   void WriteValue(char* key, char* name, S16 value);
   void WriteValue(char* key, char* name, char* value);
   void WriteValue(char* key, char* name, F32 value);
   void WriteValue(char* key, char* name, F64 value);
   void WriteValue(char* key, char* name, bool value);

   bool GetKeysInKey(char* key, std::list<std::string>* outList);
   bool GetEntriesInKey(char* key, std::list<std::string>* outList);

   void CreateKey(char* key);
   void DeleteKey(char* key);
   void RenameKey(char* key, char* newName);

private:
   char mPath[MAX_FILENAME_LEN];
   char mFilename[MAX_FILENAME_LEN];
   FILE* mFile;

   struct Entry
   {
      Entry(char* name, char* value)
      {
         mName = name;
         mValue = value;
      }
      std::string mName;
      std::string mValue;
   };

   struct Key
   {
      Key()
      {
         mName = "";
         mParent = NULL;
      }
      Key(char* name, Key* parent)
      {
         mName = name;
         mParent = parent;
      }
      ~Key()
      {
         for (std::vector<Key*>::iterator itr = mSubkeys.begin(); itr != mSubkeys.end(); itr++)
         {
            delete (*itr);
         }
         mSubkeys.clear();
      }
      std::string mName;
      std::vector<Key*> mSubkeys;
      std::vector<Entry> mEntries;
      Key* mParent;
   };

   Key mRootKey;

   void Load();
   void Save();

   void WriteKey(FILE* file, const char* path, Key* key);

   Key* GetKey(char* name, bool create);
};




#endif

