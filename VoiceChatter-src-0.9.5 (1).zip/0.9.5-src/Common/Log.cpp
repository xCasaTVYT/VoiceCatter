#include "Log.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "strings.h"
#include "platform.h"
#include <sys/stat.h>

bool Log::smInitialized(false);
time_t Log::smStartTime(0);
U64 Log::smStartMS(0);

Log::Log(const char* name, RotationPeriod rotationPeriod, bool flushAlways)
: mRotationPeriod(rotationPeriod),
  mFlushAlways(flushAlways),
  mFile(NULL),
  mNextRotationTime(0)
{
   mMutex = Mutex::Create();

   if (!smInitialized)
      Init();

   strncpy(mFileName, name, 1023);
   mFileName[1023] = '\0';

   struct stat stats;
   if (stat(mFileName, &stats) == 0)
      SetupRotation(stats.st_mtime);
   else
   {
      time_t secs;
      U16 ms;
      WhatTimeIsIt(&secs, &ms);
      SetupRotation(time(NULL));
   }

   mFile = fopen(mFileName, "a");
}

Log::~Log()
{
   if (mFile)
      fclose(mFile);
   delete mMutex;
}

void Log::Init()
{
   smStartTime = time(NULL);
   smStartMS = Platform::GetTimeMS();
   smInitialized = true;
}

void Log::Rotate()
{
   //don't rotate if we're not supposed to rotate
   assert(mRotationPeriod != Rot_Never);

   if (mFile)
   {
      char newFileName[2048];
      strcpy(newFileName, mFileName);
      //should really turn back slashes into slashes
      char* dot = strrchr(newFileName, '.');
      if (!dot || strchr(dot, '/') || strlen(dot) < 2)
         dot = newFileName + strlen(newFileName);

      tm* t = localtime(&mLastRotationTime);
      sprintf(dot, "_%04d-%02d-%02d_%02d-%02d",
         t->tm_year + 1900, t->tm_mon + 1, t->tm_mday,
         t->tm_hour, t->tm_min);
      char* dot2 = strrchr(mFileName, '.');
      if (dot2 && !strchr(dot2, '/') && strlen(dot2) > 1)
         strcat(dot, dot2);

      fclose(mFile);
      rename(mFileName, newFileName);
   }

   mFile = fopen(mFileName, "a");
   time_t secs;
   U16 ms;
   WhatTimeIsIt(&secs, &ms);
   SetupRotation(secs);
}

void Log::Write(const char* fmt, ...)
{
   mMutex->Lock();
   static const int len = 1023;
   assert(strlen(fmt) < len - 26);

   time_t when;
   U16 ms;
   WhatTimeIsIt(&when, &ms);

   if (mRotationPeriod != Rot_Never && when >= mNextRotationTime)
      Rotate();

   if (!mFile)
   {
      mMutex->Unlock();
      return;
   }

   tm* t = localtime(&when);

   //add a timestamp to the output
   fprintf(mFile, "%04d/%02d/%02d %02d:%02d:%02d.%03d = ",
      t->tm_year + 1900, t->tm_mon+1, t->tm_mday,
      t->tm_hour, t->tm_min, t->tm_sec, ms);

   va_list args;
   va_start(args, fmt);
   vfprintf(mFile, fmt, args);
   va_end(args);

   fprintf(mFile, "\n");


   if (mFlushAlways)
      fflush(mFile);
   mMutex->Unlock();
}

void Log::SetupRotation(time_t secs)
{
   if (mRotationPeriod == Rot_Never)
      return;

   static const time_t sLengths[5] = 
   {
      0, 60*60, 60*60*24, 60*60*7, 60
   };

   time_t remainder = secs % sLengths[mRotationPeriod];
   mLastRotationTime = secs - remainder;
   mNextRotationTime = mLastRotationTime + sLengths[mRotationPeriod];
}


void Log::WhatTimeIsIt(time_t* secs, U16* ms)
{
   U64 elapsed = Platform::GetTimeMS() - smStartMS;
   *secs = (time_t)(smStartTime + elapsed / 1000);
   *ms = (U16)(elapsed % 1000);
}

