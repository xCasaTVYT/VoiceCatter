#include "GuaranteedPacket.h"
#include "util.h"
#include "vprotocol.h"
#include <string.h>

GuaranteedPacket::GuaranteedPacket(U16 key, U32 seqnum, char* data, U32 size)
: mSize(size+7), mAcked(false), mSeq(seqnum)
{
   mData = new char[mSize];
   mData[0] = GUARANTEED_DATA;
   Util::SetPktU16(mData+1, key);
   Util::SetPktU32(mData+3, seqnum);
   memcpy(mData+7, data, size);
}

GuaranteedPacket::~GuaranteedPacket()
{
   delete [] mData;
}

