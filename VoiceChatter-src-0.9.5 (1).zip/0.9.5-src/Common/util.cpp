#include "util.h"

#include "net.h"

namespace Util
{
   U16 GetPktU16(char* pkt)
   {
      return ntohs(*((U16*)pkt));
   }

   U32 GetPktU32(char* pkt)
   {
      return htonl(*((U32*)pkt));
   }

   void SetPktU16(char* pkt, U16 val)
   {
      *((U16*)pkt) = htons(val);
   }

   void SetPktU32(char* pkt, U32 val)
   {
      *((U32*)pkt) = htonl(val);
   }
}

