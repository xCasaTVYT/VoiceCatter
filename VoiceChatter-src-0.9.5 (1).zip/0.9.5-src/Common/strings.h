#ifndef _STRINGS_H_
#define _STRINGS_H_

#ifdef WIN32
#define snprintf _snprintf
#endif

#ifdef LINUX
#define stricmp strcasecmp
#define strincmp strncasecmp
#endif

#endif

