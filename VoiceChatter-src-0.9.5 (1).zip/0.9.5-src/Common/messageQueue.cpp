#include "messageQueue.h"


MessageQueue::MessageQueue(void* tag, void (*callback)(void* tag, void* data))
   : mCallback(callback), mTag(tag)
{
   mMutex = Mutex::Create();
   mSemaphore = Semaphore::Create(0);
   mThread = Thread::Create(mStartupFunc);
   mThread->Start(this);
}

MessageQueue::~MessageQueue()
{
   mShuttingDown = true;
   Enqueue(NULL);
   mThread->Join();
   delete mThread;
   delete mSemaphore;
   delete mMutex;
}

void MessageQueue::Enqueue(void* data)
{
   mMutex->Lock();
   mQueue.push(data);
   mMutex->Unlock();
   mSemaphore->Inc();
}

void* MessageQueue::mStartupFunc(void* arg)
{
   MessageQueue* q = (MessageQueue*)arg;
   q->MessageLoop();
   return NULL;
}

void MessageQueue::MessageLoop()
{
   while (true)
   {
      mSemaphore->Dec();
      if (mShuttingDown)
         break;

      mMutex->Lock();
      void* data = mQueue.front();
      mQueue.pop();
      (*mCallback)(mTag, data);
      mMutex->Unlock();
   }
}

