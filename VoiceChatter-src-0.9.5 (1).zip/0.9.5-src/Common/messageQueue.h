#ifndef _MESSAGEQUEUE_H_
#define _MESSAGEQUEUE_H_

#include <queue>
#include "platform.h"

class MessageQueue
{
   public:
      MessageQueue(void* tag, void (*callback)(void* tag, void* data));
      ~MessageQueue();

      void Enqueue(void* data);

   private:
      Thread* mThread;
      Semaphore* mSemaphore;
      Mutex* mMutex;
      std::queue<void*> mQueue;
      volatile bool mShuttingDown;
      
      void* mTag;
      void (*mCallback)(void* tag, void* data);

      static void* mStartupFunc(void* arg);
      void MessageLoop();
};


#endif

