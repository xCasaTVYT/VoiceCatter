#ifndef _SOCKETS_H_
#define _SOCKETS_H_

#include "types.h"

#ifdef WIN32
#include <winsock.h>
typedef int socklen_t;
#endif

#ifdef LINUX
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>
#ifdef LINUX
typedef int SOCKET;
#define INVALID_SOCKET -1
#define closesocket(sock) close(sock)
#endif

#endif


#endif
