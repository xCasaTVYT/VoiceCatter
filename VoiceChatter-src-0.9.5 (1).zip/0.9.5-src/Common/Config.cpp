#include "Config.h"
#include "strings.h"
#include "platform.h"

Config::Config(const char* path, const char* filename)
{
   strncpy(mFilename, filename, MAX_FILENAME_LEN);
   mFilename[MAX_FILENAME_LEN-1] = '\0';

   Platform::ExpandPath(path, mPath, MAX_FILENAME_LEN-1);
   if (mPath[strlen(mPath)-1] != '/')
      strcat(mPath, "/");
   Load();
}

Config::~Config()
{
}

void Config::Load()
{
   char fullPath[MAX_FILENAME_LEN * 2];
   sprintf(fullPath, "%s%s", mPath, mFilename);

   FILE* file = fopen(fullPath, "r");
   if (!file)
   {
      //try to create the directory
      int createResult = Platform::MakeDir(mPath);
      if (createResult != 0)
         return;

      //try to create the file again
      file = fopen(fullPath, "r");
      if (!file)
         return;
   }

   const int BufferLen = 512;
   char buffer[BufferLen];

   Key* currKey = &mRootKey;
   while (fgets(buffer, BufferLen, file))
   {
      if (buffer[0] == '[')
      {
         buffer[strlen(buffer)-2] = '\0';
         currKey = GetKey(buffer+1, true);
         continue;
      }

      //"entry"="value"
      size_t lineLen = strlen(buffer);
      if (lineLen < 6)
         continue;
      if (buffer[0] != '\"')
         continue;
      if (buffer[lineLen-2] != '\"')
         continue;
      char* equals = strstr(buffer, "\"=\"");
      if (!equals)
         continue;
      
      char* entry = buffer+1;
      *equals = '\0';

      char* value = equals + 3;
      buffer[lineLen-2] = '\0';

      currKey->mEntries.push_back(Entry(entry, value));
   }

   fclose(file);
}

void Config::Save()
{
   char fullPath[MAX_FILENAME_LEN * 2];
   sprintf(fullPath, "%s%s", mPath, mFilename);

   FILE* file = fopen(fullPath, "w");
   if (!file)
      return;

   WriteKey(file, "", &mRootKey);
   //for (std::vector<Entry>::iterator itr = mRootKey.mEntries.begin(); itr != mRootKey.mEntries.end(); itr++)
   //   fprintf(file, "\"%s\"=\"%s\"\n", (*itr).mName.c_str(), (*itr).mValue.c_str());

   fclose(file);
}

void Config::WriteKey(FILE* file, const char* path, Key* key)
{
   std::string fullname = path;
   if (path[0] != '\0')
      fullname += "\\";

   fullname += key->mName;
   fprintf(file, "[%s]\n", fullname.c_str());

   for (std::vector<Entry>::iterator itr = key->mEntries.begin(); itr != key->mEntries.end(); itr++)
      fprintf(file, "\"%s\"=\"%s\"\n", (*itr).mName.c_str(), (*itr).mValue.c_str());

   for (std::vector<Key*>::iterator itr = key->mSubkeys.begin(); itr != key->mSubkeys.end(); ++itr)
      WriteKey(file, fullname.c_str(), (*itr));
}


bool Config::ReadValue(char* key, char* name, U32* value, bool create)
{
   char buff[32];
   sprintf(buff, "%u", *value);
   if (!ReadValue(key, name, buff, 32, create))
      return false;

   *value = atoi(buff);
   return true;
}

bool Config::ReadValue(char* key, char* name, U16* value, bool create)
{
   char buff[32];
   sprintf(buff, "%u", *value);
   if (!ReadValue(key, name, buff, 32, create))
      return false;

   *value = (U16)atoi(buff);
   return true;
}

bool Config::ReadValue(char* key, char* name, U8* value, bool create)
{
   char buff[32];
   sprintf(buff, "%u", *value);
   if (!ReadValue(key, name, buff, 32, create))
      return false;

   *value = (U8)atoi(buff);
   return true;
}

bool Config::ReadValue(char* key, char* name, S32* value, bool create)
{
   char buff[32];
   sprintf(buff, "%d", *value);
   if (!ReadValue(key, name, buff, 32, create))
      return false;

   *value = atoi(buff);
   return true;
}

bool Config::ReadValue(char* key, char* name, S16* value, bool create)
{
   char buff[32];
   sprintf(buff, "%d", *value);
   if (!ReadValue(key, name, buff, 32, create))
      return false;

   *value = (S16)atoi(buff);
   return true;
}

bool Config::ReadValue(char* key, char* name, char* value, size_t valueLen, bool create)
{
   Key* readKey = GetKey(key, create);
   if (!readKey)
      return false;

   for (std::vector<Entry>::iterator itr = readKey->mEntries.begin(); itr != readKey->mEntries.end(); itr++)
   {
      if (strcmp(name, (*itr).mName.c_str()) == 0)
      {
         strncpy(value, (*itr).mValue.c_str(), valueLen);
         value[valueLen-1] = '\0';
         return true;
      }
   }
   if (!create)
      return false;

   WriteValue(key, name, value);
   return true;
}

bool Config::ReadValue(char* key, char* name, F32* value, bool create)
{
   char buff[32];
   sprintf(buff, "%f", *value);
   if (!ReadValue(key, name, buff, 32, create))
      return false;

   *value = (F32)atof(buff);
   return true;
}

bool Config::ReadValue(char* key, char* name, F64* value, bool create)
{
   char buff[32];
   sprintf(buff, "%f", *value);
   if (!ReadValue(key, name, buff, 32, create))
      return false;

   *value = atof(buff);
   return true;
}

bool Config::ReadValue(char* key, char* name, bool* value, bool create)
{
   char buff[32];
   if (*value)
      strcpy(buff, "true");
   else
      strcpy(buff, "false");

   if (!ReadValue(key, name, buff, 32, create))
      return false;

   if (stricmp(buff, "true") == 0 || atoi(buff) != 0)
      *value = true;
   else
      *value = false;
   return true;
}


void Config::WriteValue(char* key, char* name, U32 value)
{
   char buff[32];
   sprintf(buff, "%u", value);
   WriteValue(key, name, buff);
}

void Config::WriteValue(char* key, char* name, U16 value)
{
   char buff[32];
   sprintf(buff, "%u", value);
   WriteValue(key, name, buff);
}

void Config::WriteValue(char* key, char* name, U8 value)
{
   char buff[32];
   sprintf(buff, "%u", value);
   WriteValue(key, name, buff);
}

void Config::WriteValue(char* key, char* name, S32 value)
{
   char buff[32];
   sprintf(buff, "%d", value);
   WriteValue(key, name, buff);
}

void Config::WriteValue(char* key, char* name, S16 value)
{
   char buff[32];
   sprintf(buff, "%d", value);
   WriteValue(key, name, buff);
}

void Config::WriteValue(char* key, char* name, char* value)
{
   Key* writeKey = GetKey(key, true);

   bool found = false;
   for (std::vector<Entry>::iterator itr = writeKey->mEntries.begin(); itr != writeKey->mEntries.end(); itr++)
   {
      if (strcmp(name, (*itr).mName.c_str()) == 0)
      {
         (*itr).mValue = value;
         found = true;
      }
   }
   if (!found)
      writeKey->mEntries.push_back(Entry(name, value));

   Save();
}

void Config::WriteValue(char* key, char* name, F32 value)
{
   char buff[32];
   sprintf(buff, "%f", value);
   WriteValue(key, name, buff);
}

void Config::WriteValue(char* key, char* name, F64 value)
{
   char buff[32];
   if (value)
      strcpy(buff, "true");
   else
      strcpy(buff, "false");
   WriteValue(key, name, buff);
}

void Config::WriteValue(char* key, char* name, bool value)
{
   char buff[32];
   sprintf(buff, "%u", value);
   WriteValue(key, name, buff);
}

bool Config::GetKeysInKey(char* key, std::list<std::string>* outList)
{
   Key* listKey = GetKey(key, false);
   if (!listKey)
      return false;

   for (std::vector<Key*>::iterator itr = listKey->mSubkeys.begin(); itr != listKey->mSubkeys.end(); ++itr)
      outList->push_back((*itr)->mName);
   return true;
}

bool Config::GetEntriesInKey(char* key, std::list<std::string>* outList)
{
   Key* listKey = GetKey(key, false);
   if (!listKey)
      return false;

   for (std::vector<Entry>::iterator itr = listKey->mEntries.begin(); itr != listKey->mEntries.end(); ++itr)
      outList->push_back((*itr).mName);
   return true;
}

void Config::CreateKey(char* key)
{
   GetKey(key, true);
   Save();
}

void Config::DeleteKey(char* key)
{
   Key* deleteKey = GetKey(key, false);
   if (!deleteKey)
      return;

   char* lastPart = strrchr(key, '\\');
   if (!lastPart)
      lastPart = key;
   else
      lastPart++;

   Key* parentKey = deleteKey->mParent;
   for (std::vector<Key*>::iterator itr = parentKey->mSubkeys.begin(); itr != parentKey->mSubkeys.end(); ++itr)
   {
      Key* thisKey = *itr;
      if (strcmp((*itr)->mName.c_str(), lastPart) == 0)
      {
         parentKey->mSubkeys.erase(itr);
         delete thisKey;
         Save();
         return;
      }
   }
}

void Config::RenameKey(char* key, char* newName)
{
   Key* renameKey = GetKey(key, false);
   if (!renameKey)
      return;

   renameKey->mName = newName;
   Save();
}

Config::Key* Config::GetKey(char* name, bool create)
{
   if (name[0] == '\0')
      return &mRootKey;

   Key* currKey = &mRootKey;
   while (true)
   {
      int strStop = (int)strcspn(name, "\\");

      bool found = false;
      for (std::vector<Key*>::iterator itr = currKey->mSubkeys.begin(); itr != currKey->mSubkeys.end(); ++itr)
      {
         if (strncmp((*itr)->mName.c_str(), name, strStop) == 0)
         {
            currKey = (*itr);
            found = true;
            break;
         }
      }

      if (!found)
      {
         if (!create)
            return NULL;

         char buff[128];
         int maxLen = strStop < 127 ? strStop : 127;
         strncpy(buff, name, maxLen);
         buff[maxLen] = '\0';
         currKey->mSubkeys.push_back(new Key(buff, currKey));
         currKey = currKey->mSubkeys.back();
      }

      if (name[strStop] == '\0')
         return currKey;
      name += strStop+1;
   }
   return NULL;
}



