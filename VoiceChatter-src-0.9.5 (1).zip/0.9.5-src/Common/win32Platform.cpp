#include "platform.h"

#include <windows.h>

__int64 gTimerFrequency;
__int64 gTimerStart;
bool gTimerInitialized = false;

void Platform::Sleep(U32 ms)
{
   ::Sleep(ms);
}

U64 Platform::GetTimeMS()
{
   LARGE_INTEGER query;
   if (!gTimerInitialized)
   {
      QueryPerformanceFrequency(&query);
      gTimerFrequency = query.QuadPart;
      QueryPerformanceCounter(&query);
      gTimerStart = query.QuadPart;
      gTimerInitialized = true;
   }
   QueryPerformanceCounter(&query);

   __int64 now = query.QuadPart;
   __int64 diff = now - gTimerStart;
   __int64 div = gTimerFrequency / 1000;
   U64 ret = (U64)(diff / div);
   return ret;
   //return (U32)GetTickCount();
}

int Platform::MakeDir(const char* dir)
{
   if (CreateDirectory(dir, NULL))
      return 0;
   return 1;
}

void Platform::ExpandPath(const char* dir, char* output, int outputSize)
{
   strncpy(output, dir, outputSize);
   output[outputSize-1] = '\0';
}



