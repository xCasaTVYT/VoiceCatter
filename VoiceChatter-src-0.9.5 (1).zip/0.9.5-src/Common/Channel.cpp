#include "Channel.h"
#include "Client.h"
#include <assert.h>

Channel::Channel(char* name, Channel* parent, U16 id, bool hasPassword)
: mParent(parent), mID(id), mHasPassword(hasPassword), mDestructing(false)
{
   strncpy(mName, name, MAX_CHANNEL_NAME_LENGTH);
   mName[MAX_CHANNEL_NAME_LENGTH] = '\0';
   
   if (mParent)
      mParent->AddSubchannel(this);
}

Channel::~Channel()
{
   //there should not be any clients in a channel when it is removed
   assert(mClients.size() == 0);

   mDestructing = true;
   for (std::map<U16, Channel*>::iterator itr = mSubchannels.begin(); itr != mSubchannels.end(); ++itr)
   {
      Channel* subchannel = (*itr).second;
      delete subchannel;
   }
   mSubchannels.clear();

   if (mParent)
      mParent->RemoveSubchannel(this);
}

void Channel::AddSubchannel(Channel* subchan)
{
   mSubchannels[subchan->GetID()] = subchan;
}

void Channel::RemoveSubchannel(Channel* subchan)
{
   if (mDestructing)
      return;
   std::map<U16, Channel*>::iterator itr = mSubchannels.find(subchan->GetID());
   if (itr == mSubchannels.end())
      return;

   mSubchannels.erase(itr);
}

void Channel::AddClient(Client* client)
{
   Channel* oldChannel = client->GetChannel();
   oldChannel->RemoveClient(client);
   mClients[client->GetID()] = client;
}

void Channel::RemoveClient(Client* client)
{
   std::map<U16, Client*>::iterator itr = mClients.find(client->GetID());
   if (itr == mClients.end())
      return;

   mClients.erase(itr);
}

void Channel::SetName(char* name)
{
   assert(strlen(name) <= MAX_CHANNEL_NAME_LENGTH);
   //the length of the name should have already been checked
   strcpy(mName, name);
}


