#ifndef _BAN_H_
#define _BAN_H_

#include "types.h"
#include <string>
#include <time.h>

//TODO: expiration time
struct Ban
{
   Ban(const char* victim, const char* admin, U32 ip, U32 subnet, const char* reason, time_t when)
      : mVictim(victim),
        mAdmin(admin),
        mIP(ip),
        mSubnet(subnet),
        mReason(reason),
        mTime(when)
   {
   }
   std::string mVictim;
   std::string mAdmin;
   U32 mIP;
   U32 mSubnet;
   time_t mTime;
   std::string mReason;
};


#endif

